﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace final_project_phonesReparing
{
    public partial class home : Form
    {

        
        // Window Styles 
        private const int CS_NOCLOSE = 0x200;
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams mdiCp = base.CreateParams;
                mdiCp.ClassStyle = mdiCp.ClassStyle | CS_NOCLOSE ;

                return mdiCp;
            }
        }
        //*************************************************************
        public home()
        {
            InitializeComponent();
        }


       

        private void button1_Click(object sender, EventArgs e)
        {
            
            if (toolStripSplitButton1.Text == "Tables")
            {
               
                toolStripSplitButton1.Text = "الجداول الرئيسه";
                toolStripSplitButton2.Text = "فلتره المحتوى";
                toolStripSplitButton3.Text = "حول";
                phonesInfoToolStripMenuItem.Text = "بيانات الهاتف";
                employeeToolStripMenuItem.Text = "بينات الموظفين";
                reparingIDToolStripMenuItem.Text = " الارقام التسلسليه للموظفين و الهواتف";
                phonesInfoToolStripMenuItem1.Text = "بيانات الهاتف";
                employeeToolStripMenuItem1.Text = "بينات الموظفين";
                dataBaseToolStripMenuItem.Text = "حول قاعده البينات";
                developerTeamToolStripMenuItem.Text = "حول المطورين";
                button2.Text = "خروج";
                button1.Text = "عربيه/انجليزيه";
                button3.Text = "مزيد من المعلومات";
             



            }
            else
            {
                toolStripSplitButton1.Text = "Tables";
                toolStripSplitButton2.Text = "Query filtering";
                toolStripSplitButton3.Text = "About";
                phonesInfoToolStripMenuItem.Text = "Phones Info";
                employeeToolStripMenuItem.Text = "Employee";
                reparingIDToolStripMenuItem.Text = "Reparing ID";
                phonesInfoToolStripMenuItem1.Text = "Phones Info";
                employeeToolStripMenuItem1.Text = "Employee";
                dataBaseToolStripMenuItem.Text = "Data Base Structures";
                developerTeamToolStripMenuItem.Text = "Developer  Team";
                button2.Text = "EXITE";
                button1.Text = "EN/AR";
                button3.Text = "More info";
              

            }

        }

        private void phonesInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            phone_show_table show_phone = new phone_show_table();
            show_phone.Show();

        }

        private void developerTeamToolStripMenuItem_Click(object sender, EventArgs e)
        {
            about_team team = new about_team();
            team.Show();

        }

        private void dataBaseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            about_DB DB_about = new about_DB();
            DB_about.Show();
        }

        private void employeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Employeeform Efrom = new Employeeform();
            Efrom.Show();
        }

        private void reparingIDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Fixid fix = new Fixid();
            fix.Show();
        }

        private void employeeToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            WORKER_Q w_q = new WORKER_Q();
            w_q.Show();
        }

        private void toolStripSplitButton2_ButtonClick(object sender, EventArgs e)
        {

        }

        private void phonesInfoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            phoneInfo INF_PHONE = new phoneInfo();
            INF_PHONE.Show();
        }

       


        private void button2_Click(object sender, EventArgs e)
        {


            this.Close();
        }

      
        private void button3_Click(object sender, EventArgs e)
        {
            if (label2.Visible == false && label3.Visible == false && label4.Visible == false)
            {


                label2.Visible = true;
                label3.Visible = true; 
                label4.Visible = true;

            }
            else { 

                label2.Visible = false;
                label3.Visible = false;
                label4.Visible = false; 
            }
        }

        private void home_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }


        

       

      
    }
}

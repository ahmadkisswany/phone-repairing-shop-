﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace final_project_phonesReparing
{
    public partial class Employeeform : Form
    {
        public Employeeform()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(final_project_phonesReparing.Properties.Settings.Default.phonesConnectionString);
        phone_RDataContext app = new phone_RDataContext();

        private void Employeeform_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = from x in app.Employees select new { x.Employee_name, x.Employee_id, x.Employee_address, x.Employee_rate, x.Employee_tell };

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                Employeez Emp = new Employeez();
                Emp.Employee_name = textBox1.Text;
                Emp.Employee_id = Convert.ToInt16(textBox2.Text);
                Emp.Employee_address = textBox3.Text;
                Emp.Employee_rate = Convert.ToInt16(textBox4.Text);
                Emp.Employee_tell = Convert.ToInt32(textBox5.Text);
                app.Employees.InsertOnSubmit(Emp);
                
                
                app.SubmitChanges();
                dataGridView1.RefreshEdit();
                Employeeform_Load(null, null);

              
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
               
            }
            catch {
                MessageBox.Show("There is an empty field, or repeat Primary key");
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
            
            
            
            
            
            }
            
        }
        /*
         
rate more than 3
name  start withe a
all id more than 2
address amman
address zarqa 
all table data
         */
        private void button1_Click(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedIndex)
            {

                case 0: dataGridView1.DataSource = from x in app.Employees


                                                   where x.Employee_rate > 3
                                                   orderby x.Employee_rate descending
                                                   select x;                                  
                                                      break;
                case 1: dataGridView1.DataSource = from x in app.Employees where x.Employee_name.StartsWith("a") || x.Employee_name.StartsWith("A") select new { x.Employee_name, x.Employee_id, x.Employee_address, x.Employee_rate, x.Employee_tell }; break;
                case 2: dataGridView1.DataSource = from x in app.Employees where x.Employee_id > 2 select x; break;
                case 3: dataGridView1.DataSource = from x in app.Employees where x.Employee_address.CompareTo("amman") == 0 || x.Employee_address.CompareTo("Amman") == 0 select new { x.Employee_name, x.Employee_id, x.Employee_address, x.Employee_rate, x.Employee_tell }; break;
                case 4: dataGridView1.DataSource = from x in app.Employees where x.Employee_address.CompareTo("zarqa") == 0 || x.Employee_address.CompareTo("Zara") == 0 select new { x.Employee_name, x.Employee_id, x.Employee_address, x.Employee_rate, x.Employee_tell }; break;
                case 5: dataGridView1.DataSource = from x in app.Employees select new { x.Employee_name, x.Employee_id, x.Employee_address, x.Employee_rate, x.Employee_tell }; break;

            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            dataGridView1.Columns[0].Visible = false; dataGridView1.Columns[2].Visible = false;
            dataGridView1.Columns[1].Visible = false; dataGridView1.Columns[3].Visible = false;
            dataGridView1.Columns[4].Visible = false;
            if (checkBox1.Checked)
            {
                dataGridView1.Columns[0].Visible = true;
            }

            if (checkBox2.Checked)
            {
                dataGridView1.Columns[1].Visible = true;

            }
            if (checkBox3.Checked)
            {

                dataGridView1.Columns[2].Visible = true;

            }
            if (checkBox4.Checked)
            {
                dataGridView1.Columns[3].Visible = true;
            }
            if (checkBox5.Checked)
            {
                dataGridView1.Columns[4].Visible = true;
            }

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace final_project_phonesReparing
{
    public partial class WORKER_Q : Form
    {
        public WORKER_Q()
        {
            InitializeComponent();
        }
        phone_RDataContext app = new phone_RDataContext();

        private void WORKER_Q_Load(object sender, EventArgs e)
        {

            dataGridView1.DataSource = from x in app.Employees select x;

        }

        private void button1_Click(object sender, EventArgs e)
        {

            /*
 get worker and phones worked in
 get worker rate more than 3 and name start with s
get  worker where tell start with  079
get  worker where tell start with  078
get  worker where tell start with  077
 get worker rate more than 3 
 get worker  address in amman

 
             */
            switch (comboBox1.SelectedIndex)
            {


                case 0: dataGridView1.DataSource = from x in app.Employees
                                                   from y in app.Phone_informations
                                                   from z in app.Repairing_ids
                                                   where x.Employee_id == z.Employee_id && y.phone_id == z.Phone_id
                                                   select new { x.Employee_id, x.Employee_name, y.phone_id, y.phone_name }; break;
                case 1:  dataGridView1.DataSource= from x in app.Employees
                           where x.Employee_rate>3 && x.Employee_name.ToUpper().StartsWith("S")  select x ; break;
                case 2: dataGridView1.DataSource = from x in app.Employees
                                                   where x.Employee_tell.ToString().StartsWith("7")&& x.Employee_tell.ToString().Substring(1,x.Employee_tell.ToString().Length).StartsWith("9")
                                                   select x;

                                                       break;

                case 3: dataGridView1.DataSource = from x in app.Employees
                                                   where x.Employee_tell.ToString().StartsWith("7") && x.Employee_tell.ToString().Substring(1, x.Employee_tell.ToString().Length).StartsWith("8")
                                                   select x;  break;
                case 4: dataGridView1.DataSource = from x in app.Employees
                                                   where x.Employee_tell.ToString().StartsWith("7") && x.Employee_tell.ToString().Substring(1, x.Employee_tell.ToString().Length).StartsWith("7")
                                                   select x; break;
                case 5: dataGridView1.DataSource = from x in app.Employees
                                                   where  x.Employee_rate>3
                                                   select x; break;
                case 6: dataGridView1.DataSource = from x in app.Employees
                                                   where x.Employee_address.ToString().ToUpper()=="AMMAN"
                                                   select x; break;
                case 7: dataGridView1.DataSource = from x in app.Employees select x; break;

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
            int id = Convert.ToInt16(numericUpDown1.Value);
            dataGridView1.DataSource = from x in app.Employees where x.Employee_id == id select x;
        }
    }
}

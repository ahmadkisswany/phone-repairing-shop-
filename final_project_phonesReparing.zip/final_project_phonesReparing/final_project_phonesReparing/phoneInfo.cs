﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace final_project_phonesReparing
{
    public partial class phoneInfo : Form
    {
        public phoneInfo()
        {
            InitializeComponent();
        }
        phone_RDataContext app = new phone_RDataContext();

        private void phoneInfo_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = from x in app.Phone_informations select x;
        }
              /*
              select id >3

 select  cost >40
 select  all data 

             
             */

        private void button1_Click(object sender, EventArgs e)
        {
          
             switch ( comboBox1.SelectedIndex)
             
             {

                 case 0: dataGridView1.DataSource = from x in app.Phone_informations where x.phone_id > 3 select new { x.phone_id,x.phone_name,x.phone_model,x.day_enter,x.cost_to_fix,x.day_end}; break;
                 case 1: dataGridView1.DataSource = from x in app.Phone_informations where x.cost_to_fix > 20 select new { x.phone_id, x.phone_name, x.phone_model, x.day_enter, x.cost_to_fix, x.day_end }; break;
                 case 2: dataGridView1.DataSource = from x in app.Phone_informations select new { x.phone_id, x.phone_name, x.phone_model, x.day_enter, x.cost_to_fix, x.day_end } ; break;
                 case 3: dataGridView1.DataSource = from x in app.Phone_informations where x.day_enter.Month.ToString().CompareTo("9")==0  select new { x.phone_id, x.phone_name, x.phone_model, x.day_enter, x.cost_to_fix, x.day_end }; break;
                 case 4: dataGridView1.DataSource = from x in app.Phone_informations where x.day_enter.Year.ToString().CompareTo("2019") == 0 select new { x.phone_id, x.phone_name, x.phone_model, x.day_enter, x.cost_to_fix, x.day_end }; break;
                 case 5: dataGridView1.DataSource = from x in app.Phone_informations where x.day_enter.Year.ToString().CompareTo("2020") == 0 select new { x.phone_id, x.phone_name, x.phone_model, x.day_enter, x.cost_to_fix, x.day_end }; break;
             }
             
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int s = Convert.ToInt16(numericUpDown1.Value.ToString());

                dataGridView1.DataSource = from x in app.Phone_informations where x.phone_id == s select x;
            }
            catch { MessageBox.Show("not  ID"); }
        }
    }
}

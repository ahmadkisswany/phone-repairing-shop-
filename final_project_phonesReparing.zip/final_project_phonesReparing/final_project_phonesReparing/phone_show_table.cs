﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using System.Data.Linq;

namespace final_project_phonesReparing
{
    public partial class phone_show_table : Form
    {
        public phone_show_table()
        {
            InitializeComponent();

        }



     
         SqlConnection con = new SqlConnection(final_project_phonesReparing.Properties.Settings.Default.phonesConnectionString);
       
         phone_RDataContext app = new phone_RDataContext( );


        

        private void phone_show_table_Load(object sender, EventArgs e)
        {
           dataGridView1.DataSource= from x in  app.Phone_informations orderby x.cost_to_fix 
                                      
                                      select new { x.phone_name,x.phone_model,x.phone_id,x.day_enter,x.day_end,x.cost_to_fix};
          
         
        }



        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
               Phone_information phone_ob = new Phone_information();
               phone_ob.phone_name = textBox1.Text;
               phone_ob.phone_model = textBox2.Text;
               phone_ob.phone_id = int.Parse(textBox3.Text);
               phone_ob.day_enter= Convert.ToDateTime(textBox4.Text);
               phone_ob.day_end =  Convert.ToDateTime(textBox5.Text);
               phone_ob.cost_to_fix= Int32.Parse(textBox6.Text);
             
               app.Phone_informations.InsertOnSubmit(phone_ob);
               
               app.SubmitChanges();

               dataGridView1.Refresh();
               this.phone_show_table_Load(null, null);
               
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
               
            }
            catch
            {
                MessageBox.Show("There is an empty field, or repeat Primary key");
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {



       dataGridView1.Columns[0].Visible = false; dataGridView1.Columns[2].Visible = false;
            dataGridView1.Columns[1].Visible = false; dataGridView1.Columns[3].Visible = false;
            dataGridView1.Columns[4].Visible = false; dataGridView1.Columns[5].Visible = false;
            if(checkBox1.Checked){
            dataGridView1.Columns[0].Visible = true;}

            if (checkBox2.Checked)
            {
                dataGridView1.Columns[1].Visible = true;

            }
            if (checkBox3.Checked) 
            {

                dataGridView1.Columns[2].Visible = true;
            
            }
            if (checkBox4.Checked)
            {
                dataGridView1.Columns[3].Visible = true;
            }
            if (checkBox5.Checked)
            {
                dataGridView1.Columns[4].Visible = true;
            }
            if (checkBox6.Checked)
            { dataGridView1.Columns[5].Visible = true; }
        }

        private void button3_Click(object sender, EventArgs e)
        {

           

            try
            {
                int rem = dataGridView1.CurrentCell.RowIndex;
                //MessageBox.Show(rem+"");
                DataGridViewRow Del = dataGridView1.Rows[rem];
                //MessageBox.Show(Del+ "");
                int t = Convert.ToInt16(Del.Cells[2].Value.ToString());

                //MessageBox.Show(""+t);
               
               Phone_information  d= app.Phone_informations.SingleOrDefault(x => x.phone_id == t);
                app.Phone_informations.DeleteOnSubmit(d);
               
              
                dataGridView1.Rows.RemoveAt(rem);
                app.SubmitChanges();
            }
            catch( Exception b){}
        }
       
      

     

        

       
        


        

     

       
           

     

        
    }
}

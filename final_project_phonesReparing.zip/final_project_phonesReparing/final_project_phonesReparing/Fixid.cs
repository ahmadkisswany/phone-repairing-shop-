﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace final_project_phonesReparing
{
    public partial class Fixid : Form
    {
        public Fixid()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(final_project_phonesReparing.Properties.Settings.Default.phonesConnectionString);
        phone_RDataContext app = new phone_RDataContext();

        private void Fixid_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = from x in app.Repairing_ids select new { x.Employee_id,x.Employee.Employee_name, x.Phone_id ,x.Phone_information.phone_name};
             

        }

        private void button1_Click(object sender, EventArgs e)
        {


            /*
             
             all id  biger than 3
            worker name start of a
            fixing cost more than 10 
             * all table data 
             
             */

           
            switch (comboBox1.SelectedIndex)
            
            {
                case 0: dataGridView1.DataSource = from x in app.Employees
                                                   from y in app.Phone_informations
                                                   where x.Employee_id > 3 && y.phone_id > 3
                                                   orderby x.Employee_id descending     
                                                   select new { x.Employee_id, x.Employee_name, y.phone_id,y.phone_name };
                                                      break;
                case 1:
                                                      dataGridView1.DataSource = from x in app.Employees
                                                                                 where x.Employee_name.ToString().StartsWith("a") || x.Employee_name.ToString().StartsWith("A")

                                                                                 select new { x.Employee_name,x.Employee_address,x.Employee_id,x.Employee_tell };
                    break;
                case 2:

                    dataGridView1.DataSource = from x in app.Phone_informations
                                               where x.cost_to_fix > 10

                                               select new { x.phone_id, x.phone_name, x.phone_model, x.cost_to_fix };
                    
                    
                    break;

                case 3: dataGridView1.DataSource = from x in app.Repairing_ids select new { x.Employee_id, x.Employee.Employee_name, x.Phone_id, x.Phone_information.phone_name };
                    break;

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dataGridView1.Columns[0].Visible = false; dataGridView1.Columns[2].Visible = false;
            dataGridView1.Columns[1].Visible = false; dataGridView1.Columns[3].Visible = false;

            if (checkBox1.Checked)
            {
                dataGridView1.Columns[0].Visible = true;
            }

            if (checkBox2.Checked)
            {
                dataGridView1.Columns[1].Visible = true;

            }
            if (checkBox3.Checked)
            {

                dataGridView1.Columns[2].Visible = true;

            }
            if (checkBox4.Checked)
            {
                dataGridView1.Columns[3].Visible = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

            try
            {
                con.Open();
                Repairing_id rep = new Repairing_id();
                rep.Phone_id = int.Parse(textBox1.Text);
                rep.Employee_id = int.Parse(textBox2.Text);
                app.Repairing_ids.InsertOnSubmit(rep);


                app.SubmitChanges();
                dataGridView1.RefreshEdit();
                Fixid_Load(null, null);


                textBox1.Clear();
                textBox2.Clear();

               



                con.Close();

            }


            catch
            {
                MessageBox.Show("sorry / cant add the data ");
                textBox1.Clear();
                textBox2.Clear();
            }
        }


    }
}

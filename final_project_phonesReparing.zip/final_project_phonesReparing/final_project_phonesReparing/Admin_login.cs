﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace final_project_phonesReparing
{
    public partial class Admin_login : Form
    {



        // Window Styles 




        private const int WS_SYSMENU = 0x80000;
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.Style &= ~WS_SYSMENU;
                return cp;
            }
        }
        //*************************************************************
        public Admin_login()
        {
            InitializeComponent();
        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }
        private void InitializeMyControl()
        {
            // Set to no text.  
           // textBox2.Text = "";
            // The password character is an asterisk.  
            if (checkBox1.Checked) { textBox2.PasswordChar = '*'; }
            else
            {
                  textBox2.PasswordChar=' ';
            }

            // The control will allow no more than 8 characters.  
            textBox2.MaxLength = 8;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            InitializeMyControl();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            if ((textBox1.Text == "Admin" || textBox1.Text == "admin") && textBox2.Text == "12345678")
            { 
                home home1 = new home();
                home1.Show();
                textBox1.Text = "";
                textBox2.Text = "";

               
            }
            else {

                MessageBox.Show("wrong password or username");
                textBox1.Text = "";
                textBox2.Text = "";
            
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            InitializeMyControl();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string message = "Do you want to close this window?";
            string title = "Close Window";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result = MessageBox.Show(message, title, buttons);
            if (result == DialogResult.Yes)
            {
                this.Close();


            }
            else
            {

            }  
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            textBox1.MaxLength = 13;
        }

       
    }
}
